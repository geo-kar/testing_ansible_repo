# nexi_ansible_jboss
Update nexi jboss aplications

There are 2 playbooks:
 - init_install_jboss -> will install jboss jdk and jboss standalone
 - update_configuration -> will update standalone and jboss config and install crontab job and script

In order to run a playbook:

Go to project diractory and run:

ansible-playbook -i inventory init_install_jboss

or 

ansible-playbook -i inventory update_configuration

In order to change values you can access the group_vars diractory and change the group variables
or access any role you want to change the default values at /roles/<any_role>/dafaults/main.yaml


